const express=require("express")
const router=express.Router();
const pool=require("../pool")
//app.js: app.use("/index",Index)
